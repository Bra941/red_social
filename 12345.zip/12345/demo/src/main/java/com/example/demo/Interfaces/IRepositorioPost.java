package com.example.demo.Interfaces;

import com.example.demo.Models.Post;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioPost extends JpaRepository<Post, Integer> {


    }

