package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioviewall;
import com.example.demo.Models.viewall;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RequestMapping("/api/comentario-post")
@RestController
public class ViewAllController {

    private final IRepositorioviewall repo;

    @Autowired
    public ViewAllController(IRepositorioviewall repo) {
        this.repo = repo;
    }

    @GetMapping("/{postId}")
    public ResponseEntity<List<viewall>> getByPostId(
            @PathVariable Integer postId) {

        List<viewall> lista = repo.findByPostId(postId);

        return ResponseEntity.ok(lista);
    }
}
