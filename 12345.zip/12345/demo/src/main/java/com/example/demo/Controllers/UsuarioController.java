package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioUsuario;
import com.example.demo.Models.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
    @Autowired
    private IRepositorioUsuario repo;

    @GetMapping
    public ResponseEntity<List<Usuario>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> get(@PathVariable Integer id) {
        Optional<Usuario> u = repo.findById(id);
        return u.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping("/activos")
    public List<Usuario> getUsuariosActivos(
            @RequestParam(value = "activo", defaultValue = "1") Integer activo) {
        return repo.findByActivo(activo);
    }
    @GetMapping("/dominio")
    public List<Usuario> getUsuariosPorDominio(
            @RequestParam("dominio") String dominio) {
        return repo.findByEmailDomain(dominio);
    }
    @GetMapping("/nombre_usuario")
    public List<Usuario> getUsuariosPorNombre(
        @RequestParam("nombreUsuario") String nombreUsuario){
        return repo.findByNombre(nombreUsuario);
    }

    @PostMapping
    public ResponseEntity<Usuario> create(@RequestBody Usuario nuevo) {
        Usuario saved = repo.save(nuevo);
        URI loc = URI.create("/api/usuarios/" + saved.getIdUsuario());
        return ResponseEntity.created(loc).body(saved);
    }


}
