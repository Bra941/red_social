package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioCompartido;
import com.example.demo.Models.Compartido;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/compartidos")

public class CompartidoController {

    @Autowired
    private IRepositorioCompartido repo;

    @GetMapping
    public ResponseEntity<List<Compartido>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Compartido> get(@PathVariable Integer id) {
        Optional<Compartido> c = repo.findById(id);
        return c.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Compartido> create(@RequestBody Compartido nuevo) {
        Compartido saved = repo.save(nuevo);
        URI loc = URI.create("/api/compartidos/" + saved.getIdCompartido());
        return ResponseEntity.created(loc).body(saved);
    }
}
