package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "me_gusta")
@Proxy(lazy = false)
// Genera referencias por ID para evitar ciclos y serializar sólo el idMegusta
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idMegusta"
)
public class Megusta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMegusta;

    @Column(name = "fechacreacion_megusta", length = 10, nullable = false)
    private String fechaCreacionMegusta;

    // En lugar de JsonIgnore, indicamos serializar sólo como ID
    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_post", nullable = false)
    private Post post;
    private Megusta(){}

    public Integer getIdMegusta() {
        return idMegusta;
    }

    public String getFechaCreacionMegusta() {
        return fechaCreacionMegusta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Post getPost() {
        return post;
    }

    public void setIdMegusta(Integer idMegusta) {
        this.idMegusta = idMegusta;
    }

    public void setFechaCreacionMegusta(String fechaCreacionMegusta) {
        this.fechaCreacionMegusta = fechaCreacionMegusta;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public Megusta(Integer idMegusta, String fechaCreacionMegusta, Usuario usuario, Post post) {
        this.idMegusta = idMegusta;
        this.fechaCreacionMegusta = fechaCreacionMegusta;
        this.usuario = usuario;
        this.post = post;
    }
}
