package com.example.demo.Interfaces;

import com.example.demo.Models.View_Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRepositorioViewPost extends JpaRepository<View_Post, Long> {
    @Query("SELECT v FROM View_Post v WHERE v.id = :id")
    List<View_Post> findByEdentity(@Param("id") Integer id);
}
