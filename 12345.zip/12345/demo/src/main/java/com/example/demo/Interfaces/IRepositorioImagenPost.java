package com.example.demo.Interfaces;

import com.example.demo.Models.ImagenPost;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioImagenPost extends JpaRepository<ImagenPost, Integer> { }

