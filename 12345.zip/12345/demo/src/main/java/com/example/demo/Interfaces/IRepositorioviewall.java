package com.example.demo.Interfaces;

import com.example.demo.Models.viewall;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IRepositorioviewall extends JpaRepository<viewall, Integer> {
    List<viewall> findByPostId(Integer postId);
}
