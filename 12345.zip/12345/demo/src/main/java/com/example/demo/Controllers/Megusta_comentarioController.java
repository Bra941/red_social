package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioMegusta_comentario;
import com.example.demo.Models.Megusta_comentario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/megustas-comentario")
public class Megusta_comentarioController {
    @Autowired
    private IRepositorioMegusta_comentario repo;

    @GetMapping("/todos")
    public ResponseEntity<List<Megusta_comentario>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Megusta_comentario> get(@PathVariable Integer id) {
        Optional<Megusta_comentario> mm = repo.findById(id);
        return mm.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Megusta_comentario> create(@RequestBody Megusta_comentario nuevo) {
        Megusta_comentario saved = repo.save(nuevo);
        URI loc = URI.create("/api/megustas-comentario/" + saved.getIdMegustaComentario());
        return ResponseEntity.created(loc).body(saved);
    }
}
