package com.example.demo.Interfaces;

import com.example.demo.Models.Megusta;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioMegusta extends JpaRepository<Megusta, Integer> { }

