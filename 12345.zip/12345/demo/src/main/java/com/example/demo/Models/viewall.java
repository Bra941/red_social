package com.example.demo.Models;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "viewall")
public class viewall {

    /*
     *   Id Integer
     *   nombre_usuario varchar
     *   fecha string
     *   imagen varchar
     *   meGusta_Comentarios
     * */


    @Id
    @Column(name="id")            // id_comentario
    private Integer id;

    @Column(name = "post_id")         // id_post para filtrar
    private Integer postId;

    @Column(name = "nombre_usuario")
    private String nombreUsuario;

    @Column(name = "contenido")
    private String contenido;

    @Column(name = "fecha")
    private String fecha;              // o LocalDateTime según tipo real

    @Column(name = "imagen")
    private String imagen;

    @Column(name = "me_gusta_comentarios")
    private Integer meGustaComentarios;

    protected viewall() { }

    public viewall(Integer id, Integer postId, String nombreUsuario, String contenido, String fecha, String imagen, Integer meGustaComentarios) {
        this.id = id;
        this.postId = postId;
        this.nombreUsuario = nombreUsuario;
        this.contenido = contenido;
        this.fecha = fecha;
        this.imagen = imagen;
        this.meGustaComentarios = meGustaComentarios;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public Integer getMeGustaComentarios() {
        return meGustaComentarios;
    }

    public void setMeGustaComentarios(Integer meGustaComentarios) {
        this.meGustaComentarios = meGustaComentarios;
    }
}
