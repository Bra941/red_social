package com.example.demo.Models;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

import java.util.List;

@Entity
@Table(name = "post")
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idPost")
@Proxy(lazy = false)
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idPost;

    @Column(name = "descripcion_post", columnDefinition = "TEXT", nullable = false)
    private String descripcionPost;

    @Column(name = "activo_post", nullable = false)
    private Integer activoPost;

    @Column(name = "fechacreacion_post", length = 10, nullable = false)
    private String fechaCreacionPost;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<ImagenPost> imagenes;

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Comentario> comentarios;

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Megusta> megustas;
    private Post(){}

    public Integer getIdPost() {
        return idPost;
    }

    public String getDescripcionPost() {
        return descripcionPost;
    }

    public Integer getActivoPost() {
        return activoPost;
    }

    public String getFechaCreacionPost() {
        return fechaCreacionPost;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public List<ImagenPost> getImagenes() {
        return imagenes;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public List<Megusta> getMegustas() {
        return megustas;
    }

    public void setIdPost(Integer idPost) {
        this.idPost = idPost;
    }

    public void setDescripcionPost(String descripcionPost) {
        this.descripcionPost = descripcionPost;
    }

    public void setActivoPost(Integer activoPost) {
        this.activoPost = activoPost;
    }

    public void setFechaCreacionPost(String fechaCreacionPost) {
        this.fechaCreacionPost = fechaCreacionPost;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setImagenes(List<ImagenPost> imagenes) {
        this.imagenes = imagenes;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public void setMegustas(List<Megusta> megustas) {
        this.megustas = megustas;
    }

    public Post(Integer idPost, String descripcionPost, Integer activoPost, String fechaCreacionPost, Usuario usuario, List<ImagenPost> imagenes, List<Comentario> comentarios, List<Megusta> megustas) {
        this.idPost = idPost;
        this.descripcionPost = descripcionPost;
        this.activoPost = activoPost;
        this.fechaCreacionPost = fechaCreacionPost;
        this.usuario = usuario;
        this.imagenes = imagenes;
        this.comentarios = comentarios;
        this.megustas = megustas;
    }
}
