package com.example.demo.Models;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

import java.util.List;

@Entity
@Table(name = "usuario")
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idUsuario")
@Proxy(lazy = false)
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idUsuario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idIconUser", nullable = false)
    private ImagenPost imagenPost;

    @Column(name = "nombre_usuario", length = 35, nullable = false, unique = true)
    private String nombreUsuario;

    @Column(name = "edad_usuario", nullable = false)
    private Integer edadUsuario;

    @Column(name = "correo_usuario", length = 50, nullable = false)
    private String correoUsuario;

    @Column(name = "contrasena_usuario", length = 120, nullable = false)
    private String contrasenaUsuario;

    @Column(name = "telefono_usuario", length = 35, nullable = false)
    private String telefonoUsuario;

    @Column(name = "fechanacimiento_usuario", length = 10, nullable = false)
    private String fechaNacimientoUsuario;

    @Column(name = "direccion_usuario", columnDefinition = "TEXT", nullable = false)
    private String direccionUsuario;

    @Column(name = "activo_usuario", nullable = false)
    private Integer activoUsuario;

    @Column(name = "fechacreacion_usuario", length = 10, nullable = false)
    private String fechaCreacionUsuario;

    /** Relaciones con otras tablas **/
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Post> posts;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Compartido> compartidos;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Comentario> comentarios;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Megusta> megustas;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIdentityReference(alwaysAsId = true)
    private List<Megusta_comentario> megustaComentarios;

    private Usuario() {}

    public Usuario(Integer idUsuario,
                   ImagenPost imagenPost,
                   String nombreUsuario,
                   Integer edadUsuario,
                   String correoUsuario,
                   String contrasenaUsuario,
                   String telefonoUsuario,
                   String fechaNacimientoUsuario,
                   String direccionUsuario,
                   Integer activoUsuario,
                   String fechaCreacionUsuario,
                   List<Post> posts,
                   List<Compartido> compartidos,
                   List<Comentario> comentarios,
                   List<Megusta> megustas,
                   List<Megusta_comentario> megustaComentarios) {
        this.idUsuario = idUsuario;
        this.imagenPost = imagenPost;
        this.nombreUsuario = nombreUsuario;
        this.edadUsuario = edadUsuario;
        this.correoUsuario = correoUsuario;
        this.contrasenaUsuario = contrasenaUsuario;
        this.telefonoUsuario = telefonoUsuario;
        this.fechaNacimientoUsuario = fechaNacimientoUsuario;
        this.direccionUsuario = direccionUsuario;
        this.activoUsuario = activoUsuario;
        this.fechaCreacionUsuario = fechaCreacionUsuario;
        this.posts = posts;
        this.compartidos = compartidos;
        this.comentarios = comentarios;
        this.megustas = megustas;
        this.megustaComentarios = megustaComentarios;
    }

    // Getters y setters

    public Integer getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public ImagenPost getImagenPost() {
        return imagenPost;
    }
    public void setImagenPost(ImagenPost imagenPost) {
        this.imagenPost = imagenPost;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public Integer getEdadUsuario() {
        return edadUsuario;
    }
    public void setEdadUsuario(Integer edadUsuario) {
        this.edadUsuario = edadUsuario;
    }

    public String getCorreoUsuario() {
        return correoUsuario;
    }
    public void setCorreoUsuario(String correoUsuario) {
        this.correoUsuario = correoUsuario;
    }

    public String getContrasenaUsuario() {
        return contrasenaUsuario;
    }
    public void setContrasenaUsuario(String contrasenaUsuario) {
        this.contrasenaUsuario = contrasenaUsuario;
    }

    public String getTelefonoUsuario() {
        return telefonoUsuario;
    }
    public void setTelefonoUsuario(String telefonoUsuario) {
        this.telefonoUsuario = telefonoUsuario;
    }

    public String getFechaNacimientoUsuario() {
        return fechaNacimientoUsuario;
    }
    public void setFechaNacimientoUsuario(String fechaNacimientoUsuario) {
        this.fechaNacimientoUsuario = fechaNacimientoUsuario;
    }

    public String getDireccionUsuario() {
        return direccionUsuario;
    }
    public void setDireccionUsuario(String direccionUsuario) {
        this.direccionUsuario = direccionUsuario;
    }

    public Integer getActivoUsuario() {
        return activoUsuario;
    }
    public void setActivoUsuario(Integer activoUsuario) {
        this.activoUsuario = activoUsuario;
    }

    public String getFechaCreacionUsuario() {
        return fechaCreacionUsuario;
    }
    public void setFechaCreacionUsuario(String fechaCreacionUsuario) {
        this.fechaCreacionUsuario = fechaCreacionUsuario;
    }

    @JsonManagedReference
    public List<Post> getPosts() {
        return posts;
    }
    @JsonManagedReference
    public void setPosts(List<Post> posts) {
        this.posts = posts;
    }

    @JsonManagedReference
    public List<Compartido> getCompartidos() {
        return compartidos;
    }
    public void setCompartidos(List<Compartido> compartidos) {
        this.compartidos = compartidos;
    }

    @JsonManagedReference
    public List<Comentario> getComentarios() {
        return comentarios;
    }
    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    @JsonManagedReference
    public List<Megusta> getMegustas() {
        return megustas;
    }
    public void setMegustas(List<Megusta> megustas) {
        this.megustas = megustas;
    }

    @JsonManagedReference
    public List<Megusta_comentario> getMegustaComentarios() {
        return megustaComentarios;
    }
    public void setMegustaComentarios(List<Megusta_comentario> megustaComentarios) {
        this.megustaComentarios = megustaComentarios;
    }
}
