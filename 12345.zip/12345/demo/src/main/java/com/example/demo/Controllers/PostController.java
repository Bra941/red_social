package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioPost;
import com.example.demo.Models.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final IRepositorioPost postRepository;

    @Autowired
    public PostController(IRepositorioPost postRepository) {
        this.postRepository = postRepository;
    }

    /**
     * GET /api/posts
     * Devuelve todos los posts.
     */

    @GetMapping
    public ResponseEntity<List<Post>> listarPosts() {
        List<Post> lista = postRepository.findAll();
        return ResponseEntity.ok(lista);
    }

    /**
     * GET /api/posts/{id}
     * Devuelve un post por su ID.
     */

    @GetMapping("/{id}")
    public ResponseEntity<Post> obtenerPost(@PathVariable Integer id) {
        Optional<Post> opt = postRepository.findById(id);
        return opt
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * POST /api/posts
     * Crea un nuevo post a partir del body JSON.
     * - JSON esperado:
     *   {
     *     "descripcionPost": "...",
     *     "activoPost": 1,
     *     "fechaCreacionPost": "2025-06-08",
     *     "usuario": { "idUsuario": 1 }
     *   }
     */

    @PostMapping
    public ResponseEntity<Post> crearPost(@RequestBody Post nuevo) {
        // Guardamos el post
        Post guardado = postRepository.save(nuevo);
        // Construimos la URI de recurso creado: /api/posts/{id}
        URI location = URI.create("/api/posts/" + guardado.getIdPost());
        return ResponseEntity.created(location).body(guardado);
    }

}
