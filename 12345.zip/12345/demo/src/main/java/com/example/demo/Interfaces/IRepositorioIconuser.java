package com.example.demo.Interfaces;

import com.example.demo.Models.Iconuser;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioIconuser extends JpaRepository<Iconuser, Integer> {
    }

