package com.example.demo.Interfaces;

import com.example.demo.Models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IRepositorioUsuario extends JpaRepository<Usuario, Integer> {

        // Ejemplo: buscar usuarios por apellido (suponiendo que Usuario tenga campo apellido)
        @Query("SELECT u FROM Usuario u WHERE u.nombreUsuario = :nombreUsuario")
        List<Usuario> findByNombre(@Param("nombreUsuario") String nombreUsuario);

        @Query("SELECT u FROM Usuario u WHERE u.activoUsuario = :activo")
        List<Usuario> findByActivo(@Param("activo") Integer activo);

        // Ejemplo con consulta nativa: buscar usuarios por dominio de correo
        @Query(
                value = "SELECT * FROM usuario u WHERE u.correo_usuario LIKE %:dominio%",
                nativeQuery = true
        )
        List<Usuario> findByEmailDomain(@Param("dominio") String dominio);
    }

