package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioIconuser;
import com.example.demo.Models.Iconuser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/iconusers")
public class IconuserController {

    @Autowired
    private IRepositorioIconuser repo;

    @GetMapping
    public ResponseEntity<List<Iconuser>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Iconuser> get(@PathVariable Integer id) {
        Optional<Iconuser> i = repo.findById(id);
        return i.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Iconuser> create(@RequestBody Iconuser nuevo) {
        Iconuser saved = repo.save(nuevo);
        URI loc = URI.create("/api/iconusers/" + saved.getIdIconUser());
        return ResponseEntity.created(loc).body(saved);
    }
}
