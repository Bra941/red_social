package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

import java.util.List;

@Entity
@Table(name = "megusta_comentario")
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idMegustaComentario")
@Proxy(lazy = false)
public class Megusta_comentario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMegustaComentario;

    @Column(name = "fechacreacion_megusta_comentario", length = 10, nullable = false)
    private String fechaCreacionMegustaComentario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_comentario", nullable = false)
    private Comentario comentario;
    private Megusta_comentario(){}

    public Integer getIdMegustaComentario() {
        return idMegustaComentario;
    }

    public String getFechaCreacionMegustaComentario() {
        return fechaCreacionMegustaComentario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Comentario getComentario() {
        return comentario;
    }

    public void setIdMegustaComentario(Integer idMegustaComentario) {
        this.idMegustaComentario = idMegustaComentario;
    }

    public void setFechaCreacionMegustaComentario(String fechaCreacionMegustaComentario) {
        this.fechaCreacionMegustaComentario = fechaCreacionMegustaComentario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setComentario(Comentario comentario) {
        this.comentario = comentario;
    }

    public Megusta_comentario(Integer idMegustaComentario, String fechaCreacionMegustaComentario, Usuario usuario, Comentario comentario) {
        this.idMegustaComentario = idMegustaComentario;
        this.fechaCreacionMegustaComentario = fechaCreacionMegustaComentario;
        this.usuario = usuario;
        this.comentario = comentario;
    }
}
