package com.example.demo.Interfaces;

import com.example.demo.Models.Megusta_comentario;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioMegusta_comentario extends JpaRepository<Megusta_comentario, Integer> { }

