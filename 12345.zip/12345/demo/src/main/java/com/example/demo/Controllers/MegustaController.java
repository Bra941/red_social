package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioMegusta;
import com.example.demo.Models.Megusta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/megustas")
public class MegustaController {

    @Autowired
    private IRepositorioMegusta repo;

    @GetMapping
    public ResponseEntity<List<Megusta>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Megusta> get(@PathVariable Integer id) {
        Optional<Megusta> m = repo.findById(id);
        return m.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Megusta> create(@RequestBody Megusta nuevo) {
        Megusta saved = repo.save(nuevo);
        URI loc = URI.create("/api/megustas/" + saved.getIdMegusta());
        return ResponseEntity.created(loc).body(saved);
    }

}
