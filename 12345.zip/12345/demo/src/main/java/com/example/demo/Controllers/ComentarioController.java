package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioComentario;
import com.example.demo.Models.Comentario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/comentarios")
public class ComentarioController {


    @Autowired
    private IRepositorioComentario repo;

    @GetMapping
    public ResponseEntity<List<Comentario>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Comentario> get(@PathVariable Integer id) {
        Optional<Comentario> com = repo.findById(id);
        return com.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Comentario> create(@RequestBody Comentario nuevo) {
        Comentario saved = repo.save(nuevo);
        URI loc = URI.create("/api/comentarios/" + saved.getIdComentario());
        return ResponseEntity.created(loc).body(saved);
    }

}
