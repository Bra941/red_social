package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "imagenpost")
@Proxy(lazy = false)
// Genera referencias por ID para evitar ciclos y serializar sólo el idMegusta
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idImagenPost"
)
public class ImagenPost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_imagenpost")
    private Integer idImagenPost;

    @Column(name = "imagen_imagenpost", length = 255, nullable = false)
    private String imagenImagenPost;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_post", nullable = false)
    private Post post;
    private ImagenPost(){}

    public Integer getIdImagenPost() {
        return idImagenPost;
    }

    public String getImagenImagenPost() {
        return imagenImagenPost;
    }

    public Post getPost() {
        return post;
    }

    public void setIdImagenPost(Integer idImagenPost) {
        this.idImagenPost = idImagenPost;
    }

    public void setImagenImagenPost(String imagenImagenPost) {
        this.imagenImagenPost = imagenImagenPost;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public ImagenPost(Integer idImagenPost, String imagenImagenPost, Post post) {
        this.idImagenPost = idImagenPost;
        this.imagenImagenPost = imagenImagenPost;
        this.post = post;
    }
}
