package com.example.demo.Interfaces;

import com.example.demo.Models.Compartido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositorioCompartido extends JpaRepository<Compartido, Integer> { }

