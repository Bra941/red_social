package com.example.demo.Models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "view_post")
public class View_Post {

    @Id
    @Column(name = "id_view_post")
    private Integer id;

    @Column(name = "post_imagen")
    private String postImagen;

    @Column(name = "post_fecha_creacion")
    private String postFechaCreacion;

    @Column(name = "post_descripcion")
    private String postDescripcion;

    @Column(name = "usuario_id")
    private Long usuarioId;

    @Column(name = "usuario_nombre")
    private String usuarioNombre;

    @Column(name = "iconuser")
    private String iconuser;

    @Column(name = "likes_count")
    private Integer likeuser;

    // Constructor protegido sin argumentos que Hibernate necesita
    protected View_Post() {
    }

    // Constructor completo (opcional, útil para tests o inicializaciones manuales)
    public View_Post(Integer id,
                    String postImagen,
                    String postFechaCreacion,
                    String postDescripcion,
                    Long usuarioId,
                    String usuarioNombre,
                    String iconuser,
                     Integer likeuser) {
        this.id = id;
        this.postImagen = postImagen;
        this.postFechaCreacion = postFechaCreacion;
        this.postDescripcion = postDescripcion;
        this.usuarioId = usuarioId;
        this.usuarioNombre = usuarioNombre;
        this.iconuser = iconuser;
        this.likeuser = likeuser;
    }

    public Integer getLikeuser() {
        return likeuser;
    }

    public void setLikeuser(Integer likeuser) {
        this.likeuser = likeuser;
    }
// Getters y setters

    public Integer   getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPostImagen() {
        return postImagen;
    }

    public void setPostImagen(String postImagen) {
        this.postImagen = postImagen;
    }

    public String getPostFechaCreacion() {
        return postFechaCreacion;
    }

    public void setPostFechaCreacion(String postFechaCreacion) {
        this.postFechaCreacion = postFechaCreacion;
    }

    public String getPostDescripcion() {
        return postDescripcion;
    }

    public void setPostDescripcion(String postDescripcion) {
        this.postDescripcion = postDescripcion;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getUsuarioNombre() {
        return usuarioNombre;
    }

    public void setUsuarioNombre(String usuarioNombre) {
        this.usuarioNombre = usuarioNombre;
    }

    public String getIconuser() {
        return iconuser;
    }

    public void setIconuser(String iconuser) {
        this.iconuser = iconuser;
    }
}
