package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "iconuser")
@Proxy(lazy = false)
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idIconUser"
)
public class Iconuser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idIconUser;

    @Column(name = "imagen_iconuser", length = 255, nullable = false)
    private String imagenIconUser;

    @Column(name = "activo_iconuser", nullable = false)
    private Integer activoIconUser;



    protected Iconuser() {}

    public Iconuser(Integer idIconUser, String imagenIconUser, Integer activoIconUser) {
        this.idIconUser = idIconUser;
        this.imagenIconUser = imagenIconUser;
        this.activoIconUser = activoIconUser;

    }

    public Integer getIdIconUser() {
        return idIconUser;
    }

    public String getImagenIconUser() {
        return imagenIconUser;
    }

    public Integer getActivoIconUser() {
        return activoIconUser;
    }

    public void setIdIconUser(Integer idIconUser) {
        this.idIconUser = idIconUser;
    }

    public void setImagenIconUser(String imagenIconUser) {
        this.imagenIconUser = imagenIconUser;
    }

    public void setActivoIconUser(Integer activoIconUser) {
        this.activoIconUser = activoIconUser;
    }


}
