package com.example.demo.Controllers;
import com.example.demo.Interfaces.IRepositorioViewPost;
import com.example.demo.Models.View_Post;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class ViewPostController {

    private final IRepositorioViewPost repo;
    public ViewPostController(IRepositorioViewPost repo) {
        this.repo = repo;
    }

    @GetMapping("/api/view_posts")
    public List<View_Post> getAllPosts() {
        return repo.findAll();
    }

    @GetMapping("/api/view_post/{id}")
    public List<View_Post> getById(@PathVariable("id") Integer id) {
        return repo.findByEdentity(id);
    }
}
