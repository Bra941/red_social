package com.example.demo.Controllers;

import com.example.demo.Interfaces.IRepositorioImagenPost;
import com.example.demo.Models.ImagenPost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/imagenposts")
public class ImagenPostController {

    @Autowired
    private IRepositorioImagenPost repo;

    @GetMapping
    public ResponseEntity<List<ImagenPost>> list() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ImagenPost> get(@PathVariable Integer id) {
        Optional<ImagenPost> img = repo.findById(id);
        return img.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ImagenPost> create(@RequestBody ImagenPost nuevo) {
        ImagenPost saved = repo.save(nuevo);
        URI loc = URI.create("/api/imagenposts/" + saved.getIdImagenPost());
        return ResponseEntity.created(loc).body(saved);
    }
}
