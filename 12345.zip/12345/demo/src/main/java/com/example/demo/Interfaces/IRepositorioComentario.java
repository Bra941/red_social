package com.example.demo.Interfaces;

import com.example.demo.Models.Comentario;
import org.springframework.data.jpa.repository.JpaRepository;


    public interface IRepositorioComentario extends JpaRepository<Comentario, Integer> { }

