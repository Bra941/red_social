package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "compartido")
@Proxy(lazy = false)
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idCompartido"
)
public class Compartido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCompartido;

    @Column(name = "fechacreacion_compartido", length = 10, nullable = false)
    private String fechaCreacionCompartido;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_post", nullable = false)
    private Post post;

    private Compartido(){}

    public Integer getIdCompartido() {
        return idCompartido;
    }

    public void setIdCompartido(Integer idCompartido) {
        this.idCompartido = idCompartido;
    }

    public String getFechaCreacionCompartido() {
        return fechaCreacionCompartido;
    }

    public void setFechaCreacionCompartido(String fechaCreacionCompartido) {
        this.fechaCreacionCompartido = fechaCreacionCompartido;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Post getPost() {
        return post;
    }

    public Compartido(Integer idCompartido, String fechaCreacionCompartido, Usuario usuario, Post post) {
        this.idCompartido = idCompartido;
        this.fechaCreacionCompartido = fechaCreacionCompartido;
        this.usuario = usuario;
        this.post = post;
    }

    public void setPost(Post post) {
        this.post = post;
    }
}
