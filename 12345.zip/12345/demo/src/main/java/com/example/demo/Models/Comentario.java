package com.example.demo.Models;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import org.hibernate.annotations.Proxy;

import java.util.List;

@Entity
@Table(name = "comentario")
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "idComentario")
@Proxy(lazy = false)
public class Comentario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idComentario;

    @Column(name = "contenido_comentario", columnDefinition = "TEXT", nullable = false)
    private String contenidoComentario;

    @Column(name = "activo_comentario", nullable = false)
    private Integer activoComentario;

    @Column(name = "fechacreacion", length = 10, nullable = false)
    private String fechaCreacion;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_post", nullable = false)
    private Post post;

    @JsonIdentityReference(alwaysAsId = true)
    @OneToMany(mappedBy = "comentario", cascade = CascadeType.ALL, orphanRemoval = true)
    private java.util.List<Megusta_comentario> megustaComentarios;
    public  Comentario(){}

    public Integer getIdComentario() {
        return idComentario;
    }

    public String getContenidoComentario() {
        return contenidoComentario;
    }

    public Integer getActivoComentario() {
        return activoComentario;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public List<Megusta_comentario> getMegustaComentarios() {
        return megustaComentarios;
    }

    public void setIdComentario(Integer idComentario) {
        this.idComentario = idComentario;
    }

    public void setContenidoComentario(String contenidoComentario) {
        this.contenidoComentario = contenidoComentario;
    }

    public void setActivoComentario(Integer activoComentario) {
        this.activoComentario = activoComentario;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public void setMegustaComentarios(List<Megusta_comentario> megustaComentarios) {
        this.megustaComentarios = megustaComentarios;
    }

    public Comentario(Integer idComentario, String contenidoComentario, Integer activoComentario, String fechaCreacion, Usuario usuario, Post post, List<Megusta_comentario> megustaComentarios) {
        this.idComentario = idComentario;
        this.contenidoComentario = contenidoComentario;
        this.activoComentario = activoComentario;
        this.fechaCreacion = fechaCreacion;
        this.usuario = usuario;
        this.post = post;
        this.megustaComentarios = megustaComentarios;
    }

}
